select * from dtl_tbl;
